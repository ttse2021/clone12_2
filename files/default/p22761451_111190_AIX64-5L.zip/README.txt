This is a patch for FMW 11.1.1.6.0/11.1.1.7.0/11.1.1.9.0 shiphomes, on IBM AIX on POWER Systems (64-bit)

Run the patch with 
    ./runInstaller PREREQ_CONFIG_LOCATION=<prereq_location>
e.g. 
    ./runInstaller PREREQ_CONFIG_LOCATION=/Oracle/22761451/prereq
